package org.boutique.Dao;

import org.boutique.Entities.Boutique;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


//persistence des données Objet relationnel à base de JPA-Hibernate
//Generation d'un API Rest pour Le requetage à distance
@RepositoryRestResource
public interface BoutiqueRepository extends JpaRepository<Boutique,Long>{
}
