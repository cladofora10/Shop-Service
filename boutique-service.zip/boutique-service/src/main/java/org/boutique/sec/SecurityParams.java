package org.boutique.sec;

//les parametre de JWT
public interface SecurityParams {
    public static final String HEADER_NAME="Authorization";
    public static final String SECRET="imad@imad";
    public static final long EXPIRATION=10*24*3600*1000;
    public static final String HEADER_PREFIX="Bearer ";

}
