package org.boutique;

import org.boutique.Dao.BoutiqueRepository;
import org.boutique.Entities.Boutique;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BoutiqueServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoutiqueServiceApplication.class, args);
    }
    @Bean
    CommandLineRunner start(BoutiqueRepository boutiqueRepository){
        return args -> {
//l'ajout des boutiques pour les tests
            boutiqueRepository.save(new Boutique(null,"Zara Boutique","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"Marwa","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"ASCS Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"BA Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"LC Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"Berear Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"BSan Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"BAll Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"Mongo Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"SBR Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"ALi Shop","/",Math.random()*1000));
            boutiqueRepository.save(new Boutique(null,"Aladin Shop","/",Math.random()*1000));

            boutiqueRepository.findAll().forEach(System.out::println);
        };
    }
}
